<?php  $x = 10;
	do {
echo 'Anak ayam turun 10, mati satu tinggal <option>'.$x.'</option>';
$x+-;
}
while ($x < 3);
?>